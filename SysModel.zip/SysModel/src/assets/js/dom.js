$(function () {
  var DH=document.documentElement.clientHeight;
  var DW=document.documentElement.clientWidth;
  // $(".Home").height(DH);
})
